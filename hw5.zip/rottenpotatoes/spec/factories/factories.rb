FactoryGirl.define do
    factory :movie do
        title 'New Movie'
        rating 'R'
        description 'No description'
        release_date '11-03-1995'
    end
end
